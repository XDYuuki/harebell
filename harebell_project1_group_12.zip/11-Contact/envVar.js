const envVars = {
    MY_EMAIL: "harebell.contact@gmail.com",
    MY_PASSWORD: "74EA192F59BD049C5E9F6276C5A497DB7D31",
};

/*
harebell.contact@gmail.com
senha: harebell1234

https://smtpjs.com/
STPM server: https://app.elasticemail.com/
*/
