class Product {
    _name = "";
    _description = "";
    _price = 0;
    _srcImg = "";

    Product(name, description, price, srcImg) {
        this._name = name;
        this._description = description;
        this._price = price;
        this._srcImg = srcImg;
    }
}
